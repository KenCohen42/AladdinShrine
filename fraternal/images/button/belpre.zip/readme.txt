button text: Belpre
primary color: 990000
gradient color: 660000
width (pixels): 250
height (pixels): 24
corner radius (pixels): 15
text height (points): 12
text color: dddddd
background color: clear
font name: HelvBoldOblique
rollover primary color: cb9600
rollover gradient color: 990000
rollover text color: 660000
quality: 3
image location: none
image height (pixels): 12
image name: 
image foreground color determination: auto
image foreground color: 000000
image transparent color determination: auto
image transparent color: ffffff
url: http://glassybuttons.com/glassy.php?button_text=Belpre&amp;color=990000&amp;grcolor=660000&amp;width=250&amp;height=24&amp;radius=15&amp;theight=12&amp;tcolor=dddddd&amp;bkcolor=clear&amp;fname=HelvBoldOblique&amp;rcolor=cb9600&amp;rgrcolor=990000&amp;rtcolor=660000&amp;imglocate=none&amp;imgheight=12&amp;imgname=&amp;imgfore=auto&amp;imgforecolor=000000&amp;imgtran=auto&amp;imgtrancolor=ffffff&amp;quality=3&amp;fromhere=1
